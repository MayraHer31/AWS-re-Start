print("Count to 10!")

for x in range (0, 11):
    print(x)
    
"""En Python, puede incluir una gran cantidad de funcionalidad en pocas palabras. 
Esta característica hace que Python sea relativamente fácil de escribir en 
comparación con otros lenguajes de programación, pero también puede hacer que el 
código Python sea más difícil de leer. En esta actividad, utilizará la 
instrucción for, pero también dedicará un poco de tiempo analizándola después de 
verla en acción."""